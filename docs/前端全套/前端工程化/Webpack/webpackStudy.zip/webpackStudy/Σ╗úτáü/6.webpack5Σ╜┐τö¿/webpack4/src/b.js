import * as a from './a';

export { a };
